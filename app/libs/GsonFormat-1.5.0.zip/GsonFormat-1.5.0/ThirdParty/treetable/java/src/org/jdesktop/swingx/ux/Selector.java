package org.jdesktop.swingx.ux;

/**
 * Created by dim on 16/11/7.
 */
public interface Selector {

    void setSelect(boolean select);

}
