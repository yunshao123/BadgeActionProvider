package org.gsonformat.intellij.process;


/**
 * Created by dim on 16/11/7.
 */
class GsonProcessor extends Processor {

}
