package org.gsonformat.intellij.process;

/**
 * Created by dim on 16/11/7.
 */
public class OtherProcessor extends Processor {
}
